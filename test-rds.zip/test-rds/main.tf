# Building the environment for i-decide application. Both Dev ad Prod envrionments are very similar.
# Define AWS as our provider
provider "aws" {
  region                   = var.aws_region
  shared_credentials_files = var.my_credentials
  profile                  = var.my_profile
  default_tags {
    tags = {
      Location = "Paris"
      Client   = "Chanel"
      backup   = "Yes"
    }
  }
}

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 4.2"
    }
  }
  //  backend "s3" {
  //    bucket = "s3-topic-leader-backup-recovery"
  //    key    = "infrastucture/main/terraform.tfstate"
  //    region = "eu-west-1"
  //  }
  required_version = ">= 0.12"
}

# Define SSH key pair for our instances
resource "aws_key_pair" "default" {
  key_name   = "vpc_keypair"
  public_key = file(var.key_path)
}

data "aws_caller_identity" "current" {}

data "aws_iam_role" "iam-read-s3" {
  name = "aws-s3-read-policy"
}

# Ai rajouté les lignes pour variabilser les "availability zone" dans le script terraform
data "aws_availability_zones" "available" {
}

module "vpc" {
  source = "./vpc/"

  aws_az_a              = var.aws_az_a
  aws_az_b              = var.aws_az_b
  vpc_cidr              = var.vpc_cidr
  public_subnet_cidr_a  = var.public_subnet_cidr_a
  public_subnet_cidr_b  = var.public_subnet_cidr_b
  private_subnet_cidr_a = var.private_subnet_cidr_a
  private_subnet_cidr_b = var.private_subnet_cidr_b
  env                   = var.env
}

module "appidecide" {
  source = "./ec2/appidecide/"

  ami               = var.ami_appidecide
  instance_type     = var.instance_type_appidecide
  sg_appidecide_id  = module.vpc.sg_appidecide_id
  public_subnet_id  = module.vpc.public_subnet_a_id
  private_subnet_id = module.vpc.private_subnet_a_id
  key_pair          = aws_key_pair.default.id
  private_ip        = var.private_ip_appidecide
  env               = var.env
}
/*
resource "aws_eip" "appidecide_public_ip" {
  instance = module.appidecide.appidecide_id
  vpc      = true
  tags = {
    Name          = "EIP Topic Leader"
    Environnement = var.env
  }
}
*/
module "appidecide-b" {
  source = "./ec2/appidecide/"

  ami               = var.ami_appidecide
  instance_type     = var.instance_type_appidecide
  sg_appidecide_id  = module.vpc.sg_appidecide_id
  public_subnet_id  = module.vpc.public_subnet_b_id
  private_subnet_id = module.vpc.private_subnet_b_id
  key_pair          = aws_key_pair.default.id
  private_ip        = var.private_ip_appidecide-b
  env               = var.env
}

module "sqlclient" {
  source = "./ec2/sqlclient/"

  ami               = var.ami_sqlclient
  sg_sqlclient_id   = module.vpc.sg_sqlclient_id
  public_subnet_id  = module.vpc.public_subnet_b_id
  private_subnet_id = module.vpc.private_subnet_b_id
  key_pair          = aws_key_pair.default.id
  name              = var.name_sqlclient
  private_ip        = var.private_ip_sqlclient
  instance_type     = var.instance_type_sqlclient
  env               = var.env
}

resource "aws_db_subnet_group" "my_db_subnet_group" {
  name       = "my_db_subnet_group"
  subnet_ids = [module.vpc.private_subnet_a_id, module.vpc.private_subnet_b_id]
  tags = {
    Name = "My DB subnet group"
  }
}

module "db" {
  source = "./database/"

  allocated_storage = var.allocated_storage_space
  storage_type      = var.storage_type
  engine            = var.engine
  engine_version    = var.engine_version
  instance_class    = var.instance_class
  db_name           = var.db_name
  username          = var.username
  password          = var.password
  db_subnet_group   = aws_db_subnet_group.my_db_subnet_group.id
  db_security_group = module.vpc.sg_db_idecide_id
  env               = var.env
  name              = var.name
  db_identifier     = var.db_identifier
}
