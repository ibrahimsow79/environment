/*
output "appidecide_ip" {
  value = aws_eip.appidecide_public_ip.public_ip
}
*/
output "appidecide-b_ip" {
  value = module.appidecide-b.appidecide_ip
}

output "sqlclient_ip" {
  value = var.private_ip_sqlclient
}

output "db_subnet_group_id" {
  value = aws_db_subnet_group.my_db_subnet_group.id
}

output "database_endpoint" {
  value = module.db.database_endpoint_id
}
output "account_id" {
  value = data.aws_caller_identity.current.account_id
}

output "caller_arn" {
  value = data.aws_caller_identity.current.arn
}

output "caller_user" {
  value = data.aws_caller_identity.current.user_id
}
